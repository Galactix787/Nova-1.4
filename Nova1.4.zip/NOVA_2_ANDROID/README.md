# NOVA 2.0 Android

Neues natives Android-Grundgerüst für NOVA.

Enthält:
- native Android UI statt WebView
- V-Core mit animiertem Glow
- Touch-Rotation
- Parallelogramm-artig gestaltete Controls
- Voice Input
- Chat UI
- Systemstatus
- Basis für Plugin/Model Manager

Wichtig:
Der llama.cpp Runner wird als nächster Build-Schritt als native/NDK-Komponente eingebunden.
Diese Version ist absichtlich ein sauberes Android-Projekt und kein weiterer Termux-Webserver.
