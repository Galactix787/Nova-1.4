package com.nova.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var core: VCoreView
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var rotationX = 0f
    private var rotationY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(2,2,3))
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(22, 12, 16, 8)
        }
        val logo = TextView(this).apply {
            text = "N O V A"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = .22f
        }
        status = TextView(this).apply {
            text = "● SYSTEM"
            textSize = 10f
            setTextColor(Color.WHITE)
            setPadding(14, 8, 14, 8)
            background = stroke(Color.WHITE, 1f)
        }
        header.addView(logo, LinearLayout.LayoutParams(0, 55, 1f))
        header.addView(status)
        root.addView(header)

        val coreFrame = FrameLayout(this)
        core = VCoreView(this)
        coreFrame.addView(core, FrameLayout.LayoutParams(-1, -1))
        root.addView(coreFrame, LinearLayout.LayoutParams(-1, 0, 1.15f))

        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 4, 16, 4)
        }
        val scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, .72f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 5, 12, 12)
        }
        val save = button("CHAT SPEICHERN").apply {
            textSize = 10f
            setOnClickListener { toast("Chat lokal gespeichert") }
        }
        bottom.addView(save, LinearLayout.LayoutParams(-2, 42).apply { gravity = Gravity.CENTER })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val mic = button("🎙").apply {
            textSize = 18f
            setOnClickListener { startVoice() }
        }
        input = EditText(this).apply {
            hint = "Mit NOVA reden..."
            hintTextColor = Color.rgb(100,100,105)
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(15, 0, 15, 0)
            background = stroke(Color.rgb(55,55,60), 1f)
        }
        val send = button("➤").apply {
            textSize = 20f
            setTextColor(Color.rgb(255,90,50))
            setOnClickListener { sendMessage() }
        }
        row.addView(mic, LinearLayout.LayoutParams(54, 54))
        row.addView(input, LinearLayout.LayoutParams(0, 54, 1f).apply { setMargins(7,0,7,0) })
        row.addView(send, LinearLayout.LayoutParams(54, 54))
        bottom.addView(row)
        root.addView(bottom)

        setContentView(root)

        coreFrame.setOnTouchListener { _, e ->
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { rotationX=e.x; rotationY=e.y; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx=e.x-rotationX; val dy=e.y-rotationY
                    core.rotY += dx*.35f; core.rotX -= dy*.35f
                    rotationX=e.x; rotationY=e.y; core.invalidate(); true
                }
                else -> true
            }
        }
    }

    private fun sendMessage() {
        val text=input.text.toString().trim()
        if(text.isEmpty()) return
        addMessage(text, true)
        input.text=""
        status.text="● THINKING"
        status.setTextColor(Color.rgb(255,80,40))
        addMessage("Lokaler KI-Core ist vorbereitet. Verbinde hier den llama.cpp Model Runner.", false)
        status.text="● SYSTEM"
        status.setTextColor(Color.WHITE)
    }

    private fun addMessage(text:String, user:Boolean) {
        val tv=TextView(this).apply {
            this.text=text
            textSize=15f
            setTextColor(Color.WHITE)
            setPadding(15,12,15,12)
            background=stroke(if(user) Color.rgb(95,35,25) else Color.rgb(35,35,40),1f)
        }
        val lp=LinearLayout.LayoutParams(-1,-2)
        lp.setMargins(0,5,0,5)
        chat.addView(tv,lp)
    }

    private fun startVoice() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),100); return
        }
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMAN.toLanguageTag())
        startActivityForResult(i,101)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==101 && resultCode==RESULT_OK) {
            input.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "")
        }
    }

    private fun button(t:String)=Button(this).apply {
        text=t; setTextColor(Color.WHITE); background=stroke(Color.rgb(75,75,80),1f)
        stateListAnimator=null
    }

    private fun stroke(c:Int,w:Float)=GradientDrawable().apply {
        setColor(Color.rgb(6,6,8)); setStroke(w.toInt(),c); cornerRadius=2f
    }

    private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()

    class VCoreView(ctx:android.content.Context):View(ctx) {
        var rotX=0f; var rotY=0f
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private var tick=0f
        init { setLayerType(View.LAYER_TYPE_SOFTWARE,null) }
        override fun onDraw(c:Canvas) {
            super.onDraw(c)
            val cx=width/2f; val cy=height/2f
            tick += .018f
            val glow=Paint(Paint.ANTI_ALIAS_FLAG)
            glow.shader=RadialGradient(cx,cy,180f,intArrayOf(Color.argb(75,255,55,15),Color.TRANSPARENT),null,Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,180f,glow)

            c.save()
            c.rotate(45f + sin(tick)*2f,cx,cy)
            val r=min(width,height)*.18f
            p.style=Paint.Style.STROKE;p.strokeWidth=7f
            p.setShadowLayer(35f,0f,0f,Color.rgb(255,55,20))
            p.shader=LinearGradient(cx-r,cy-r,cx+r,cy+r,Color.rgb(255,155,45),Color.rgb(245,25,25),Shader.TileMode.CLAMP)
            c.drawRoundRect(cx-r,cy-r,cx+r,cy+r,22f,22f,p)
            p.clearShadowLayer();p.shader=null
            p.style=Paint.Style.FILL
            p.setShadowLayer(30f,0f,0f,Color.rgb(20,130,255))
            p.color=Color.rgb(35,145,255)
            val ir=r*.46f
            c.drawRoundRect(cx-ir,cy-ir,cx+ir,cy+ir,15f,15f,p)
            p.clearShadowLayer()
            c.restore()

            postInvalidateDelayed(16)
        }
    }
}